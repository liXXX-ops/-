package com.example.calculate;

import androidx.appcompat.app.AppCompatActivity;

import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.os.Bundle;
import android.content.Intent;
import android.widget.EditText;
import java.lang.Integer;
import java.lang.String;
import android.widget.Spinner;

public class Main3Activity extends AppCompatActivity {
    private Button bn_jisuanqi;

    private Button bnl_g;
    private Button bnl_kg;
    private Button bnl_cm;
    private Button bnl_m;

    private Button bnr_g;
    private Button bnr_kg;
    private Button bnr_cm;
    private Button bnr_m;

    private Button bn1;
    private Button bn2;
    private Button bn3;
    private Button bn4;
    private Button bn5;
    private Button bn6;
    private Button bn7;
    private Button bn8;
    private Button bn9;
    private Button bn0;
    private Button bn_clear;
    private Button bn_OK;
    private Button bn3_jisuanqi;
    private Button bn3_point;

    private EditText edittext_in;
    private EditText edittext_out;
    String input="";
    String output="";
    String number_in="";
    String number_out="";
    double number_input=0;
    double number_output=0;
    String str[]=new String[3];  //瀛樻斁鍓嶅悗鐨勮繘鍒?

    Spinner sp_in;
    Spinner sp_out;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        bn1 = (Button) findViewById(R.id.button3_1);
        bn2 = (Button) findViewById(R.id.button3_2);
        bn3 = (Button) findViewById(R.id.button3_3);
        bn4 = (Button) findViewById(R.id.button3_4);
        bn5 = (Button) findViewById(R.id.button3_5);
        bn6 = (Button) findViewById(R.id.button3_6);
        bn7 = (Button) findViewById(R.id.button3_7);
        bn8 = (Button) findViewById(R.id.button3_8);
        bn9 = (Button) findViewById(R.id.button3_9);
        bn0 = (Button) findViewById(R.id.button3_0);
        bn_clear=(Button) findViewById(R.id.button3_clear);
        bn3_point=(Button)findViewById(R.id.button3_point);

        //bn3_jisuanqi=(Button)findViewById(R.id.button3_jisuanqi);

        sp_in=(Spinner)findViewById(R.id.spinner_in);
        sp_out=(Spinner)findViewById(R.id.spinner_out);
        edittext_in=(EditText)findViewById(R.id.button_in);
        edittext_out=(EditText)findViewById(R.id.button_output);

        String arr[]={"g","kg","cm","m","cm^3","m^3"};
///涓嬫媺妗嗭細

        /*spType.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String info = (String) spType.getSelectedItem();
                Toast.makeText(MainActivity.this,info,Toast.LENGTH_LONG).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
*/
        ///杈撳叆鏃剁殑涓嬫媺妗嗭細
        ArrayAdapter<String>adapter=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,arr);
        sp_in.setAdapter(adapter);
        sp_in.getAdapter().toString();
        sp_in.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
                number_in=input;
                str[0] = (String) sp_in.getSelectedItem();
                input=input+str[0];
                edittext_in.setText(input);
            }
            public void onNothingSelected(AdapterView<?> parent){

            }
        });
//杈撳嚭鏃剁殑涓嬫媺妗嗭細
        ArrayAdapter<String>adapter_out=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,arr);
        sp_out.setAdapter(adapter);
        sp_out.getAdapter().toString();
        sp_out.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
                str[1] = (String) sp_out.getSelectedItem();
                edittext_out.setText(str[1]);
                output=new MyClickListener().zhuanhuan()+str[1];  //寮曠敤鍙︿竴涓被涓殑zhuanhuan()鍑芥暟锛?
                edittext_out.setText(output);
            }
            public void onNothingSelected(AdapterView<?> parent){

            }
        });

        bn1.setOnClickListener(new MyClickListener());
        bn2.setOnClickListener(new MyClickListener());
        bn3.setOnClickListener(new MyClickListener());
        bn4.setOnClickListener(new MyClickListener());
        bn5.setOnClickListener(new MyClickListener());
        bn6.setOnClickListener(new MyClickListener());
        bn7.setOnClickListener(new MyClickListener());
        bn8.setOnClickListener(new MyClickListener());
        bn9.setOnClickListener(new MyClickListener());
        bn0.setOnClickListener(new MyClickListener());
        bn_clear.setOnClickListener(new MyClickListener());
        bn3_point.setOnClickListener(new MyClickListener());

/*        bnl_g.setOnClickListener(new MyClickListener());
        bnl_kg.setOnClickListener(new MyClickListener());
        bnl_cm.setOnClickListener(new MyClickListener());
        bnl_m.setOnClickListener(new MyClickListener());
        bnr_g.setOnClickListener(new MyClickListener());
        bnr_kg.setOnClickListener(new MyClickListener());
        bnr_cm.setOnClickListener(new MyClickListener());
        bnr_m.setOnClickListener(new MyClickListener());*/

        bn3_jisuanqi = (Button) findViewById(R.id.button3_jisuanqi);  //鐣岄潰杞崲
        bn3_jisuanqi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Main3Activity.this, MainActivity.class);
                startActivity(intent);
            }
        });

    }
    class MyClickListener implements View.OnClickListener {
        public void onClick(View v) {
            switch (v.getId()) {
                case R.id.button3_0: {
                    input = input + bn0.getText();
                    edittext_in.setText(input);
                    //String input=edittext.getText().toString();
                    // Toast.makeText(MainActivity.this,input,Toast.LENGTH_SHORT).show();//鏄剧ず鏂囨湰琛岀殑鍐呭锛屼互寮圭獥鐨勫舰寮?
                    break;
                }
                case R.id.button3_1: {
                    input = input + bn1.getText().toString();
                    edittext_in.setText(input);
                    break;
                }
                case R.id.button3_2: {
                    //edittext.setText(bn2.getText());
                    input = input + bn2.getText().toString();
                    edittext_in.setText(input);
                    break;
                }
                case R.id.button3_3: {
                    input = input + bn3.getText().toString();
                    edittext_in.setText(input);
                    break;
                }
                case R.id.button3_4: {
                    input = input + bn4.getText().toString();
                    edittext_in.setText(input);
                    break;
                }
                case R.id.button3_5: {
                    input = input + bn5.getText().toString();
                    edittext_in.setText(input);
                    break;
                }
                case R.id.button3_6: {
                    input = input + bn6.getText().toString();
                    edittext_in.setText(input);
                    break;
                }
                case R.id.button3_7: {
                    input = input + bn7.getText().toString();
                    edittext_in.setText(input);
                    break;
                }
                case R.id.button3_8: {
                    input = input + bn8.getText().toString();
                    edittext_in.setText(input);
                    break;
                }
                case R.id.button3_9: {
                    input = input + bn9.getText().toString();
                    edittext_in.setText(input);
                    break;
                }

                case R.id.button3_clear: {
                    input = "";
                    output="";
                    edittext_in.setText(input);
                    edittext_out.setText(output);
                    break;
                }
                case R.id.button3_point:{
                    //output=zhuanhuan()+output;
                    //edittext_out.setText(output);
                    input = input + bn3_point.getText().toString();
                    edittext_in.setText(input);
                }
                /*case R.id.buttonl_g:
                    number_in=input;
                    input=input+"g";
                    str[0]=bnl_g.getText().toString();
                    edittext_in.setText(input);
                    break;
                case R.id.buttonl_kg:
                    number_in=input;
                    str[0]=bnl_kg.getText().toString();
                    input=input+"kg";
                    edittext_in.setText(input);
                    break;
                case R.id.buttonl_cm:
                    number_in=input;
                    input=input+"cm";
                    str[0]=bnl_cm.getText().toString();
                    edittext_in.setText(input);
                    break;
                case R.id.buttonl_m:
                    number_in=input;
                    input=input+"m";
                    str[0]=bnl_m.getText().toString();
                    edittext_in.setText(input);
                    break;


                case R.id.buttonr_g:
                    str[1]=bnr_g.getText().toString();
                    output="g";
                    output=zhuanhuan()+output;
                    edittext_out.setText(output);
                    //edittext_out.setText(output);
                    break;
                case R.id.buttonr_kg:
                    str[1]=bnr_kg.getText().toString();
                    output="kg";
                    edittext_out.setText(output);
                    output=zhuanhuan()+output;

              */
                /*
                    edittext_out.setText(output);
                    break;
                case R.id.buttonr_cm:
                    str[1]=bnr_cm.getText().toString();
                    output="cm";
                    output=zhuanhuan()+output;
                    edittext_out.setText(output);
                    //edittext_out.setText(output);
                    break;
                case R.id.buttonr_m:
                    str[1]=bnr_m.getText().toString();
                    output="m";
                    output=zhuanhuan()+output;
                    edittext_out.setText(output);
                    //edittext_out.setText(output);
                    break;*/
            }
        }
        //number_input=Long.parseLong(number_in);
        public String zhuanhuan(){
            //number_input=Double.parseDouble(number_in);
            int re=0;
            String s="";
            switch(str[0]){
                //Log.d("Main2Activity","str[0]");
                case "g":
                    //if else if灏嗕竴涓竴涓殑閬嶅巻
                    //equals鍏ㄩ儴绛変簬锛?=閮ㄥ垎绛変簬灏卞彲浠?
                    if(str[1].equals("g"))s=number_in;
                    else s=String.valueOf(Double.parseDouble(number_in)/1000);
                    //else s="error";
                    break;
                case "kg":
                    if(str[1].equals("kg"))s=number_in;
                    else if(str[1].equals("g"))s=String.valueOf(Double.parseDouble(number_in)*1000);
                    else s="error";
                    break;
                case "cm":
                    if(str[1].equals("cm"))s=number_in;
                    else if(str[1].equals("m"))s=String.valueOf(Double.parseDouble(number_in)/100);
                    else s="error";
                    break;
                case "m":
                    if(str[1].equals("m"))s=number_in;
                    else if(str[1].equals("cm"))s=String.valueOf(Double.parseDouble(number_in)*100);
                    else s="error";
                    break;
                case "cm^3":
                    if(str[1].equals("cm^3"))s=number_in;
                    else if(str[1].equals("m^3"))s=String.valueOf(Double.parseDouble(number_in)/1000000);
                    else s="error";
                    break;
                case "m^3":
                    if(str[1].equals("m^3"))s=number_in;
                    else if(str[1].equals("cm^3"))s=String.valueOf(Double.parseDouble(number_in)*1000000);
                    else s="error";
                    break;
            }
            return s;
        }
    }
}
