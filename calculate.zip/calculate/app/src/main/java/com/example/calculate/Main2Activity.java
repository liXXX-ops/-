package com.example.calculate;
import androidx.appcompat.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.os.Bundle;
import android.content.Intent;
import android.widget.EditText;
import java.lang.Integer;
import java.lang.String;
public class Main2Activity extends AppCompatActivity {
    private Button bn_jisuanqi;

    private Button bnl_2;
    private Button bnl_8;
    private Button bnl_10;
    private Button bnl_16;

    private Button bnr_2;
    private Button bnr_8;
    private Button bnr_10;
    private Button bnr_16;

    private Button bn1;
    private Button bn2;
    private Button bn3;
    private Button bn4;
    private Button bn5;
    private Button bn6;
    private Button bn7;
    private Button bn8;
    private Button bn9;
    private Button bn0;
    private Button bn_clear;
    private Button bn_OK;

    private EditText edittext_in;
    private EditText edittext_out;
    String input="";
    String output="";
    String number_in="";
    String number_out="";
    int number_input=0;
    int number_output=0;
    String str[]=new String[2];  //瀛樻斁鍓嶅悗鐨勮繘鍒?
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        bn1 = (Button) findViewById(R.id.button2_1);
        bn2 = (Button) findViewById(R.id.button2_2);
        bn3 = (Button) findViewById(R.id.button2_3);
        bn4 = (Button) findViewById(R.id.button2_4);
        bn5 = (Button) findViewById(R.id.button2_5);
        bn6 = (Button) findViewById(R.id.button2_6);
        bn7 = (Button) findViewById(R.id.button2_7);
        bn8 = (Button) findViewById(R.id.button2_8);
        bn9 = (Button) findViewById(R.id.button2_9);
        bn0 = (Button) findViewById(R.id.button2_0);
        bn_clear=(Button) findViewById(R.id.button2_clear);
        bn_OK=(Button) findViewById(R.id.button_OK);
        // bn_in=(Button)findViewById(R.id.button_in);

        bnl_2 = (Button) findViewById(R.id.buttonl_2);
        bnl_8 = (Button) findViewById(R.id.buttonl_8);
        bnl_10 = (Button) findViewById(R.id.buttonl_10);
        bnl_16 = (Button) findViewById(R.id.buttonl_16);   //left

        bnr_2 = (Button) findViewById(R.id.buttonr_2);
        bnr_8 = (Button) findViewById(R.id.buttonr_8);
        bnr_10= (Button) findViewById(R.id.buttonr_10);
        bnr_16 = (Button) findViewById(R.id.buttonr_16);

        bn1.setOnClickListener(new MyClickListener());
        bn2.setOnClickListener(new MyClickListener());
        bn3.setOnClickListener(new MyClickListener());
        bn4.setOnClickListener(new MyClickListener());
        bn5.setOnClickListener(new MyClickListener());
        bn6.setOnClickListener(new MyClickListener());
        bn7.setOnClickListener(new MyClickListener());
        bn8.setOnClickListener(new MyClickListener());
        bn9.setOnClickListener(new MyClickListener());
        bn0.setOnClickListener(new MyClickListener());
        bn_clear.setOnClickListener(new MyClickListener());
        bn_OK.setOnClickListener(new MyClickListener());

        bnl_2.setOnClickListener(new MyClickListener());
        bnl_8.setOnClickListener(new MyClickListener());
        bnl_10.setOnClickListener(new MyClickListener());
        bnl_16.setOnClickListener(new MyClickListener());
        bnr_2.setOnClickListener(new MyClickListener());
        bnr_8.setOnClickListener(new MyClickListener());
        bnr_10.setOnClickListener(new MyClickListener());
        bnr_16.setOnClickListener(new MyClickListener());


        bn_jisuanqi = (Button) findViewById(R.id.button_jisuanqi);  //鐣岄潰杞崲
        bn_jisuanqi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Main2Activity.this, MainActivity.class);
                startActivity(intent);
            }
        });
        edittext_in=(EditText)findViewById(R.id.button_in);
        edittext_out=(EditText)findViewById(R.id.button_output);
    }

    class MyClickListener implements View.OnClickListener {
        public void onClick(View v) {
            switch (v.getId()) {
                case R.id.button2_0: {
                    input = input + bn0.getText();
                    edittext_in.setText(input);
                    //String input=edittext.getText().toString();
                    // Toast.makeText(MainActivity.this,input,Toast.LENGTH_SHORT).show();//鏄剧ず鏂囨湰琛岀殑鍐呭锛屼互寮圭獥鐨勫舰寮?
                    break;
                }
                case R.id.button2_1: {
                    input = input + bn1.getText().toString();
                    edittext_in.setText(input);
                    break;
                }
                case R.id.button2_2: {
                    //edittext.setText(bn2.getText());
                    input = input + bn2.getText().toString();
                    edittext_in.setText(input);
                    break;
                }
                case R.id.button2_3: {
                    input = input + bn3.getText().toString();
                    edittext_in.setText(input);
                    break;
                }
                case R.id.button2_4: {
                    input = input + bn4.getText().toString();
                    edittext_in.setText(input);
                    break;
                }
                case R.id.button2_5: {
                    input = input + bn5.getText().toString();
                    edittext_in.setText(input);
                    break;
                }
                case R.id.button2_6: {
                    input = input + bn6.getText().toString();
                    edittext_in.setText(input);
                    break;
                }
                case R.id.button2_7: {
                    input = input + bn7.getText().toString();
                    edittext_in.setText(input);
                    break;
                }
                case R.id.button2_8: {
                    input = input + bn8.getText().toString();
                    edittext_in.setText(input);
                    break;
                }
                case R.id.button2_9: {
                    input = input + bn9.getText().toString();
                    edittext_in.setText(input);
                    break;
                }

                case R.id.button2_clear: {
                    input = "";
                    output="";
                    edittext_in.setText(input);
                    edittext_out.setText(output);
                    break;
                }
                case R.id.button_OK:{
                    output=zhuanhuan()+output;
                    edittext_out.setText(output);
                }
                case R.id.buttonl_2:
                    number_in=input;
                    input=input+"(2)";
                    str[0]=bnl_2.getText().toString();
                    edittext_in.setText(input);
                    break;
                case R.id.buttonl_8:
                    number_in=input;
                    str[0]=bnl_8.getText().toString();
                    input=input+"(8)";
                    edittext_in.setText(input);
                    break;
                case R.id.buttonl_10:
                    number_in=input;
                    input=input+"(10)";
                    str[0]=bnl_10.getText().toString();
                    edittext_in.setText(input);
                    break;
                case R.id.buttonl_16:
                    number_in=input;
                    input=input+"(16)";
                    str[0]=bnl_16.getText().toString();
                    edittext_in.setText(input);
                    break;
                case R.id.buttonr_2:
                    str[1]=bnr_2.getText().toString();
                    output="(2)";
                    output=zhuanhuan()+output;
                    edittext_out.setText(output);
                    //edittext_out.setText(output);
                    break;
                case R.id.buttonr_8:
                    str[1]=bnr_8.getText().toString();
                    output="(8)";
                    edittext_out.setText(output);
                    output=zhuanhuan()+output;
                    edittext_out.setText(output);
                    break;
                case R.id.buttonr_10:
                    str[1]=bnr_10.getText().toString();
                    output="(10)";
                    output=zhuanhuan()+output;
                    edittext_out.setText(output);
                    //edittext_out.setText(output);
                    break;
                case R.id.buttonr_16:
                    str[1]=bnr_16.getText().toString();
                    output="(16)";
                    output=zhuanhuan()+output;
                    edittext_out.setText(output);
                    //edittext_out.setText(output);
                    break;
            }
        }
        //number_input=Long.parseLong(number_in);
        public String zhuanhuan(){
            number_input=Integer.parseInt(number_in);
            int re=0;
            String s="0";
            switch(str[1]){
                //Log.d("Main2Activity","str[0]");
                case "2":
                    re=toTen();
                    s=Tento(re);
                    break;
                case "8":
                    re=toTen();
                    s=Tento(re);
                    break;
                case "10":
                    re=toTen();
                    s=Tento(re);
                    break;
                case "16":
                    re=toTen();
                    s=Tento(re);
                    break;
            }
            return s;
        }

        public int toTen(){
            String s;
            int leng=number_in.length();
            int re=0;
            int t=1;
            //int result;
            switch(str[0]){
                case "2":{
                    for(int i=leng-1;i>=0;i--){
                        s=String.valueOf(number_in.charAt(i));
                        re=re+Integer.parseInt(s)*t;
                        t=t*2;
                    }
                    break;}
                case "8":
                    for(int i=leng-1;i>=0;i--){
                        s=String.valueOf(number_in.charAt(i));
                        re=re+Integer.parseInt(s)*t;
                        t=t*8;
                    }
                    break;
                case "10":
                    re=Integer.parseInt(number_in);
                    break;
                case "16":
                    for(int i=leng-1;i>=0;i--){
                        s=String.valueOf(number_in.charAt(i));
                        re=re+Integer.parseInt(s)*t;
                        t=t*16;
                    }
                    break;
            }
            return re;
        }
        public String Tento(int re){
            String s="";
            String s_result="";
            int yushu=0;
            //if(re==0)s=s+"0";
            switch(str[1]){
                case "2":{
                    while(re>0||yushu>0){
                        yushu=re%2;
                        re=re/2;
                        s=String.valueOf(yushu)+s;
                    }
                    break;}
                case "8":
                    while(re>0||yushu>0){
                        yushu=re%8;
                        re=re/8;
                        s=String.valueOf(yushu)+s;
                    }
                    break;
                case "10":
                    s=String.valueOf(re);
                    break;
                case "16":
                    while(re>0||yushu>0){
                        yushu=re%16;
                        re=re/16;
                        s=String.valueOf(yushu)+s;
                    }
                    break;
            }
            /*int j=0;
            if(str[1]=="10")
                s_result=s;
            else {
                for (int i = s.length() - 1; i >= 0; i--) {
                    s_result = s_result + String.valueOf(s.charAt(i));
                    j++;
                }
            }*/
            return s;
        }

    }
}
