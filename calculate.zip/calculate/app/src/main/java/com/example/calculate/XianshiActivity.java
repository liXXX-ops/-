package com.example.calculate;
import androidx.appcompat.app.*;
import android.os.*;
import  android.widget.*;
import android.view.*;
import android.content.*;
import java.util.*;
import android.database.sqlite.*;
import android.database.*;
public class XianshiActivity extends AppCompatActivity{
MyDBHelper myDBHelper;
ArrayList<String> items;
ListView listView;
Button backto;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_xianshi);

        //mDBHelper=new WordsDBHelper(this,"wordsdb.db",factory,1);//会出现空指针异常；
        myDBHelper = new MyDBHelper(this, "calculatedb.db", null, 1);
        listView = (ListView) findViewById(R.id.listview);
        backto=(Button)findViewById(R.id.bbb);
        //输出返回过来的单词：
        Intent intent=getIntent();
        items=getAll("calculate");
        ArrayAdapter<String> adapter=new ArrayAdapter<String>(this,R.layout.item,items);
        listView.setAdapter(adapter);
        backto.setOnClickListener(new View.OnClickListener() {
            @Override

            public void onClick(View v) {
                Intent intent=new Intent(XianshiActivity.this,MainActivity.class);
                startActivity(intent);
            }
        });

    }
    public ArrayList<String> getAll(String tablename){
        ArrayList<String> list=new ArrayList<>();
        SQLiteDatabase db=myDBHelper.getReadableDatabase();
        Cursor cursor=db.query(tablename,null,null,null,null,null,null);
        int columns= cursor.getColumnCount();
        while(cursor.moveToNext()){
            //ArrayList<String>list1=new ArrayList<>();
            for(int i=0;i<columns;i++){
                String name= cursor.getColumnName(i);   //为表中的列名，id,,,name;
                String values= cursor.getString(cursor.getColumnIndex(name));
                list.add(values);
            }
        }
        return list;
    }

}
