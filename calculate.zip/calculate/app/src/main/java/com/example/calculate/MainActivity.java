package com.example.calculate;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.Button;
import android.view.View ;
import android.widget.EditText;

import java.util.Stack;
import android.content.Intent;
import android.view.*;
import java.util.*;
import android.database.*;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    MyDBHelper myDBHelper;
    private Button bn1;
    private Button bn2;
    private Button bn3;
    private Button bn4;
    private Button bn5;
    private Button bn6;
    private Button bn7;
    private Button bn8;
    private Button bn9;
    private Button bn0;
    private Button bn_and;
    private Button bn_sub;
    private Button bn_che;
    private Button bn_chu;
    private Button bn_point;
    private Button bn_percent;
    private Button bn_result;
    private Button bn_right;
    private Button bn_left;
    private Button bn_clear;
    private Button bn_xx;
    private Button bn_xxx;
    private Button bn_sin;
    private Button bn_cos;
    private Button bn_change;
    private Button bn_jinzhi;
    private Button bn_help;

    private Button bn_tan;
    private Button bn_xz;   //x!
    private Button bn_log;
    private Button bn_ex;
    private Button bn_1x;   //1/x
    private Button bn_jueduizhi;   //|X|
    private Button bn_asin;
    private Button bn_acos;   //
    private Button bn_atan;
    private Button bn_e;
    private Button bn_In;   //
    private Button bn_pei;


    private EditText edittext;
    private String input = "";
    private int[] leng = new int[100];  //鍙備笌璁＄畻鐨勫紡瀛愮殑闀垮害
    private double[] number = new double[100];
    private char[] chars = new char[100];
    private int i = 1;
    private int j = 0;
    Stack<Double> number_stack = new Stack<>();
    Stack<Character> chars_stack = new Stack<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        bn1 = (Button) findViewById(R.id.button1);
        bn2 = (Button) findViewById(R.id.button2);
        bn3 = (Button) findViewById(R.id.button3);
        bn4 = (Button) findViewById(R.id.button4);
        bn5 = (Button) findViewById(R.id.button5);
        bn6 = (Button) findViewById(R.id.button6);
        bn7 = (Button) findViewById(R.id.button7);
        bn8 = (Button) findViewById(R.id.button8);
        bn9 = (Button) findViewById(R.id.button9);
        bn0 = (Button) findViewById(R.id.button0);
        bn_and = (Button) findViewById(R.id.button_and);
        bn_sub = (Button) findViewById(R.id.button_sub);
        bn_che = (Button) findViewById(R.id.button_che);
        bn_chu = (Button) findViewById(R.id.button_chu);
        bn_percent = (Button) findViewById(R.id.button_percent);
        bn_point = (Button) findViewById(R.id.button_point);
        bn_clear = (Button) findViewById(R.id.button_clear);
        bn_left = (Button) findViewById(R.id.button_left);
        bn_right = (Button) findViewById(R.id.button_right);
        bn_result = (Button) findViewById(R.id.button_result);
        bn_xx=(Button)findViewById(R.id.button_xx);
        bn_xxx=(Button)findViewById(R.id.button_xxx);
        bn_sin=(Button)findViewById(R.id.button_sin);
        bn_cos=(Button)findViewById(R.id.button_cos);
        bn_change=(Button)findViewById(R.id.button_change);
        bn_jinzhi=(Button)findViewById(R.id.button_jinzhi);
        bn_help=(Button)findViewById(R.id.button_help);

        bn_tan=(Button)findViewById(R.id.button_tan);
        bn_xz=(Button)findViewById(R.id.button_xz);
        bn_log=(Button)findViewById(R.id.button_log);
        bn_ex=(Button)findViewById(R.id.button_ex);
        bn_1x=(Button)findViewById(R.id.button_1x);
        bn_jueduizhi=(Button)findViewById(R.id.button_jueduizhi);
        bn_asin=(Button)findViewById(R.id.button_asin);
        bn_acos=(Button)findViewById(R.id.button_acos);
        bn_atan=(Button)findViewById(R.id.button_atan);
        bn_In=(Button)findViewById(R.id.button_In);
        bn_e=(Button)findViewById(R.id.button_e);
        bn_pei=(Button)findViewById(R.id.button_pei);

        bn1.setOnClickListener(new MyClickListener());
        bn2.setOnClickListener(new MyClickListener());
        bn3.setOnClickListener(new MyClickListener());
        bn4.setOnClickListener(new MyClickListener());
        bn5.setOnClickListener(new MyClickListener());
        bn6.setOnClickListener(new MyClickListener());
        bn7.setOnClickListener(new MyClickListener());
        bn8.setOnClickListener(new MyClickListener());
        bn9.setOnClickListener(new MyClickListener());
        bn0.setOnClickListener(new MyClickListener());

        bn_and.setOnClickListener(new MyClickListener());
        bn_sub.setOnClickListener(new MyClickListener());
        bn_che.setOnClickListener(new MyClickListener());
        bn_chu.setOnClickListener(new MyClickListener());
        bn_point.setOnClickListener(new MyClickListener());
        bn_percent.setOnClickListener(new MyClickListener());
        bn_right.setOnClickListener(new MyClickListener());
        bn_left.setOnClickListener(new MyClickListener());
        bn_clear.setOnClickListener(new MyClickListener());
        bn_result.setOnClickListener(new MyClickListener());
        bn_xx.setOnClickListener(new MyClickListener());
        bn_xxx.setOnClickListener(new MyClickListener());
        bn_sin.setOnClickListener(new MyClickListener());
        bn_cos.setOnClickListener(new MyClickListener());
        bn_help.setOnClickListener(new MyClickListener());
        bn_tan.setOnClickListener(new MyClickListener());
        bn_xz.setOnClickListener(new MyClickListener());
        bn_log.setOnClickListener(new MyClickListener());
        bn_ex.setOnClickListener(new MyClickListener());
        bn_1x.setOnClickListener(new MyClickListener());
        bn_jueduizhi.setOnClickListener(new MyClickListener());
        bn_asin.setOnClickListener(new MyClickListener());
        bn_acos.setOnClickListener(new MyClickListener());
        bn_atan.setOnClickListener(new MyClickListener());
        bn_In.setOnClickListener(new MyClickListener());
        bn_e.setOnClickListener(new MyClickListener());
        bn_pei.setOnClickListener(new MyClickListener());

        myDBHelper = new MyDBHelper(this, "calculatedb.db", null, 1);
        /*Button create=(Button)findViewById(R.id.create);
        create.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                myDBHelper.getWritableDatabase();
            }
        });*/
        bn_change.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent intent=new Intent(MainActivity.this,Main2Activity.class);
                startActivity(intent);
            }
        });
        bn_jinzhi.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent intent=new Intent(MainActivity.this,Main3Activity.class);
                startActivity(intent);
            }
        });
        edittext = (EditText) findViewById(R.id.edit);
        leng[0] = -1;
        number[0] = 0;

        //SQLiteDatabase db=myDBHelper.getReadableDatabase();  //创建数据库；
    }
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        switch (id) {
            case R.id.jisuan:
                Intent intent = new Intent(MainActivity.this, XianshiActivity.class);
                startActivity(intent);
                break;
        }
        return super.onOptionsItemSelected(item);
    }
    class MyClickListener implements View.OnClickListener {
        public void onClick(View v) {
            switch (v.getId()) {
                case R.id.button_asin:{
                    double result=Double.parseDouble(input);
                    double a=Math.asin(result);
                    input="asin"+input+"="+String.valueOf(a);
                    edittext.setText(input);
                    addtodatabase();
                break;}
                case R.id.button_acos:{
                    double result=Double.parseDouble(input);
                    double a=Math.acos(result);
                    input="acos"+input+"="+String.valueOf(a);
                    edittext.setText(input);
                    addtodatabase();
                    break;}
                case R.id.button_atan:{
                    double result=Double.parseDouble(input);
                    double a=Math.atan(result);
                    input="atan"+input+"="+String.valueOf(a);
                    edittext.setText(input);
                    addtodatabase();
                    break;}
                case R.id.button_e:{
                    input="e=2.71828";
                    edittext.setText(input);
                    addtodatabase();
                    break;}
                case R.id.button_pei:{
                    input="pei=3.1415926";
                    edittext.setText(input);
                    addtodatabase();
                    break;}
                case R.id.button_In:{
                    double result=Double.parseDouble(input);
                    result=result-result*result/2+result*result*result/3-Math.pow(result,4)/4;
                    input="In("+input+")="+String.valueOf(result);
                    edittext.setText(input);
                    addtodatabase();
                    break;}
                case R.id.button_tan:{
                    double result=Double.parseDouble(input);
                    if(result==30)result=0.577;
                    else if(result==60)result=1.73;
                    else if(result==0)result=0;
                    else if(result==90)result=10000000;
                    input="sin"+input+"="+String.valueOf(result);
                    edittext.setText(input);
                    addtodatabase();
                    break;}
                case R.id.button_xz:{
                    double result=Double.parseDouble(input);
                    double num=1;
                    for(int i=1;i<=result;i++)
                        num=num*i;
                    input=input+"!="+String.valueOf(num);
                    edittext.setText(input);
                    addtodatabase();
                    break;}
                case R.id.button_log:{
                    double result=Double.parseDouble(input);
                    double aaa=Math.log(result);
                    input="log"+input+"="+String.valueOf(aaa);
                    edittext.setText(input);
                    addtodatabase();
                    break;}

                case R.id.button_ex:{
                    double result=Double.parseDouble(input);
                    double e=2.718;
                    if(result>=0)
                        result=Math.pow(e,result);
                    else
                        result=1/Math.pow(e,Math.abs(result));
                    input="e^"+input+"="+String.valueOf(result);
                    edittext.setText(input);
                    addtodatabase();
                    break;}
                case R.id.button_1x:{
                    double result=Double.parseDouble(input);
                    if(result==0)
                        edittext.setText("error");
                    else{
                        input="1/"+input+"="+String.valueOf(1/result);
                        edittext.setText(input);
                    }
                    addtodatabase();
                    break;}
                case R.id.button_jueduizhi:{
                    double result=Double.parseDouble(input);
                    char []aa=input.toCharArray();
                    if(aa[0]=='-')
                        input="|"+input+"|="+input.substring(1,input.length());
                    else
                        input="|"+input+"|="+input;
                    edittext.setText(input);
                    addtodatabase();
                    break;}

                case R.id.button_xx:{
                    double result=Double.parseDouble(input);
                    result=result*result;
                    input=input+"^2="+String.valueOf(result);
                    edittext.setText(input);
                    addtodatabase();
                    break;
                }
                case R.id.button_xxx:{
                    double result=Double.parseDouble(input);
                    result=result*result*result;
                    input=input+"^3="+String.valueOf(result);
                    edittext.setText(input);
                    addtodatabase();
                    break;
                }
                case R.id.button_sin:{
                    double result=Double.parseDouble(input);
                    if(result==30)result=0.5;
                    else if(result==60)result=0.87;
                    else if(result==0||result==180)result=0;
                    else if(result==90)result=1;
                    else
                        result=result-result*result*result/3/2/1+result*result*result*result*result/5/4/3/2/1;
                    input="sin"+input+"="+String.valueOf(result);
                    edittext.setText(input);
                    addtodatabase();
                    break;
                }
                case R.id.button_cos:{
                    double result=Double.parseDouble(input);
                    if(result==30)result=0.87;
                    else if(result==60)result=0.5;
                    else if(result==0||result==180)result=1;
                    else if(result==90)result=0;
                    else result=1-result*result/2/1+result*result*result*result/4/3/2/1;
                    input="cos"+input+"="+String.valueOf(result);
                    edittext.setText(input);
                    addtodatabase();
                    break;
                }
                case R.id.button0: {
                    input = input + bn0.getText();
                    edittext.setText(input);
                    //String input=edittext.getText().toString();
                    // Toast.makeText(MainActivity.this,input,Toast.LENGTH_SHORT).show();//鏄剧ず鏂囨湰琛岀殑鍐呭锛屼互寮圭獥鐨勫舰寮?
                    break;
                }
                case R.id.button1: {
                    input = input + bn1.getText().toString();
                    edittext.setText(input);
                    break;
                }
                case R.id.button2: {
                    //edittext.setText(bn2.getText());
                    input = input + bn2.getText().toString();
                    edittext.setText(input);
                    break;
                }
                case R.id.button3: {
                    input = input + bn3.getText().toString();
                    edittext.setText(input);
                    break;
                }
                case R.id.button4: {
                    input = input + bn4.getText().toString();
                    edittext.setText(input);
                    break;
                }
                case R.id.button5: {
                    input = input + bn5.getText().toString();
                    edittext.setText(input);
                    break;
                }
                case R.id.button6: {
                    input = input + bn6.getText().toString();
                    edittext.setText(input);
                    break;
                }
                case R.id.button7: {
                    input = input + bn7.getText().toString();
                    edittext.setText(input);
                    break;
                }
                case R.id.button8: {
                    input = input + bn8.getText().toString();
                    edittext.setText(input);
                    break;
                }
                case R.id.button9: {
                    /*
                    String inputText = edittext.getText().toString();
                    Toast.makeText(MainActivity.this, inputText, Toast.LENGTH_SHORT).show();
                    */
                    input = input + bn9.getText().toString();
                    edittext.setText(input);
                    break;
                }
                case R.id.button_and: {
                    leng[i] = input.length();
                    i++;
                    input = input + bn_and.getText().toString();
                    edittext.setText(input);

                    chars[j] = bn_and.getText().toString().charAt(0);
                    j++;

                    break;
                    //if()//涓や釜+鐨勫垽鍒?
                }
                case R.id.button_sub: {
                    leng[i] = input.length();
                    i++;
                    input = input + bn_sub.getText().toString();
                    edittext.setText(input);

                    chars[j] = bn_sub.getText().toString().charAt(0);
                    j++;

                    break;
                }
                case R.id.button_che: {
                    leng[i] = input.length();
                    i++;
                    input = input + bn_che.getText().toString();
                    edittext.setText(input);

                    chars[j] = bn_che.getText().toString().charAt(0);
                    j++;

                    break;
                }
                case R.id.button_chu: {
                    leng[i] = input.length();
                    i++;
                    input = input + bn_chu.getText().toString();
                    edittext.setText(input);

                    chars[j] = bn_chu.getText().toString().charAt(0);
                    j++;

                    break;
                }
                case R.id.button_point: {
                    input = input + bn_point.getText().toString();
                    edittext.setText(input);
                    break;
                }
                case R.id.button_percent: {
                    input = input + bn_percent.getText().toString();
                    edittext.setText(input);
                    //leng[i]=input.length();
                    //i++;
                    break;
                }
                case R.id.button_left: {
                    input = input + bn_left.getText().toString();
                    edittext.setText(input);

                    chars[j] = bn_left.getText().toString().charAt(0);
                    j++;
                    break;
                }
                case R.id.button_right: {
                    input = input + bn_right.getText().toString();
                    edittext.setText(input);

                    chars[j] = bn_right.getText().toString().charAt(0);
                    j++;
                    break;
                }
                case R.id.button_clear: {
                    input = "";
                    i = 1;
                    j = 0;
                    //chars=null;   //pass--鍥犱笅娆¤緭鍏ユ椂涓嶈兘杈撳叆绗﹀彿锛涗笉娓呯┖浜嗭紝璁╁叾鐩存帴浠?寮€濮嬮噸鍐欙紱
                    //char chars[]=new char[100];
                    edittext.setText(input);
                    break;
                }
                case R.id.button_result: {
                    leng[i] = input.length();
                    i++;
                    //String s1=input.substring(0,leng[0]);
                    //int num1=Integer.parseInt(s1);
                    input = input + bn_result.getText().toString();
                    //input=input+String.valueOf(i);
                    //input=input+String.valueOf(j);
                    //input=input+"000";
                    edittext.setText(input);
                    //String s2=input.substring(leng[0]+1,leng[1]);
                    //int num2=Integer.parseInt(s2);
                    //int num=num1+num2;
                    //String s=String.valueOf(num);
                    //input=input+s;
                    calculate();
                    // edittext.setText(str);鏈夌偣鎱?
                    break;
                }
                case R.id.button_help:{
                    AlertDialog.Builder dialog=new AlertDialog.Builder(MainActivity.this);
                    dialog.setTitle("操作技巧");
                    dialog.setMessage("请根据键盘进行输入，转换界面请按单位转换和进制转换两个界面");
                            dialog.setCancelable(false);
                    dialog.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                        }
                    });
                    dialog.setNegativeButton("cancel", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                        }
                    });
                    dialog.show();
                }
                default:
                    break;
            }
        }

        char OP[] = {'+', '-', '*', '/', '(', ')', '='}; //寤虹珛鏁扮粍OP锛屽瓨鍌ㄨ繍绠楃鍙?
        int m[][] = {{1, 1, 2, 2, 2, 1, 1},       //纭畾杩愮畻绗﹀彿涔嬮棿鐨勪紭鍏堢骇
                {1, 1, 2, 2, 2, 1, 1},
                {1, 1, 1, 1, 2, 1, 1},
                {1, 1, 1, 1, 2, 1, 1},
                {2, 2, 2, 2, 2, 0, -1},
                {1, 1, 1, 1, -1, 1, 1},
                {2, 2, 2, 2, 2, -1, 0}};

        char Precede(char c1, char c2) {//鍒ゆ柇涓や釜杩愮畻绗︿箣闂寸殑浼樺厛绾?
            int a = 0, b = 0;
            char z = '0';
            for (int p = 0; p < 7; p++)
                if (c1 == OP[p]) a = p;
            for (int q = 0; q < 7; q++)
                if (c2 == OP[q]) b = q;
            switch (m[a][b]) {
                case 0:
                    z = '=';
                    break;
                case 1:
                    z = '>';
                    break;
                case 2:
                    z = '<';
                    break;
            }
            return z;
        }

        double Operator(double a, char thera, double b) {
            double c = 0;
            switch (thera) {
                case '+':
                    c = a + b;
                    break;
                case '-':
                    c = a - b;
                    break;
                case '*':
                    c = a * b;
                    break;
                case '/':
                    c = a / b;
                    break;
            }
            return c;
        }

        boolean In(char c) {
            for (int t = 0; t < 7; t++)
                if (c == OP[t])
                    return true;
            return false;
        }


        public void calculate() {
            double num = 0;
            double num1 = 0;
            /*
            String s1 = input.substring(0, leng[1]);
            num1 = Double.parseDouble(s1);
            number[1] = num1;
            int k = 0;
            String s2 = input.substring(leng[1] + 1, leng[2]);
            double num2 = Double.parseDouble(s2);
            number[2] = num2;

            if (j == 1) {
                switch (chars[0]) {
                    case '+': {
                        num = number[1] + number[2];
                        break;
                    }
                }
                String s = String.valueOf(num);
                input = input + s;
                edittext.setText(input);
            }
        */
        /*
           /* for (k = 0; k < i - 1; k++) {  //鏈夊寘鍚粨鏋滄暟
                // Log.d("MainActivity","leng[k]");
                String s1 = input.substring(leng[k] + 1, leng[k + 1]);
                //  Log.d("MainActivity",s1);
                //   if (s1.charAt(s1.length()-1) == '%') {   //%鍙锋娴嬶紱
                //     s1 = s1.substring(leng[k]+1, leng[k+1] - 1);
                //   num1 = Double.parseDouble(s1) / 100;
                //} else
                if (s1.charAt(s1.length() - 1) == '%') {
                    s1 = s1.substring(leng[k] + 1, leng[k + 1] - 1);
                    num1 = Double.parseDouble(s1) / 100;
                } else
                    num1 = Double.parseDouble(s1);
                number[k + 1] = num1;
            }

            */
            char c[]=input.toCharArray();

            chars_stack.push('=');
            int m = 1;
            int n = 0;
            int t = 0;
            while (input.charAt(t) != '='||chars_stack.peek()!='=') {
                String s = "";
                //c=getchar();
                //for (t = 0; t <= input.length(); t++) {
                if(!In(c[t])){
                    //if ((input.charAt(t) >= '0' && input.charAt(t) <= '9') || input.charAt(t) == '.' || input.charAt(t) == '%') {
                    while(!In(c[t])) {
                        s=s+c[t];
                        t++;
                    }
                    //if (input.charAt(t) == '+' || input.charAt(t) == '-' || input.charAt(t) == '*' || input.charAt(t) == '/'
                    // || input.charAt(t) == '(' || input.charAt(t) == ')' || input.charAt(t) == '=') {
                    if (s.charAt(s.length() - 1) == '%') {
                        s = s.substring(0, s.length() - 1);
                        num1 = Double.parseDouble(s) / 100;
                        //number_stack.push(num1);
                    } else
                        num1 = Double.parseDouble(s);
                    number_stack.push(num1);
                    s="";
                    //t--;
                }

                else {
                    switch (Precede(chars_stack.peek(), input.charAt(t))) {
                        case '<':
                            chars_stack.push(input.charAt(t));
                            t++;
                            break;
                        case '=':
                            chars_stack.pop();
                            t++;
                            break;
                        case '>': {
                            double a = number_stack.pop();
                            double b = number_stack.pop();
                            number_stack.push(Operator(b, chars_stack.pop(), a));
                            break;
                        }
                    }
                }
            }
            input = input + String.valueOf(number_stack.pop());
            edittext.setText(input);
            SQLiteDatabase db=myDBHelper.getWritableDatabase();
            ContentValues values=new ContentValues();
            values.put("shizi",input);
            db.insert("calculate",null,values);
            values.clear();
            //Toast.makeText(MainActivity.this,"kkk",Toast.LENGTH_SHORT).show();
        }
        public void addtodatabase(){
            SQLiteDatabase db=myDBHelper.getWritableDatabase();
            ContentValues values=new ContentValues();
            values.put("shizi",input);
            db.insert("calculate",null,values);
            values.clear();
        }
    }
    private ArrayList<Map<String, String>> getAll(String table_name) {
        ArrayList<Map<String, String>> list = new ArrayList<>();
        SQLiteDatabase db = myDBHelper.getReadableDatabase();
        Cursor c = db.query(table_name, null, null, null, null, null, null);
        int colums = c.getColumnCount();
        while(c.moveToNext()){
            Map<String, String> map = new HashMap<String, String>();
            for (int i = 0; i < colums; i++) {
                String word1 = c.getColumnName(i);
                String value1 = c.getString(c.getColumnIndex(word1));
                map.put(word1, value1);
            }
            list.add(map);
        }
        return list;
    }
}



















// String s2=input.substring(leng[1]+1,leng[2]);
// double num2=Double.parseDouble(s2);
// number[2]=num2;
        /*
        if (j == 1) {
            switch (chars[0]) {
                case '+': {
                    num = number[1] + number[2];
                    break;
                }
                case '-': {
                    num = number[1] - number[2];
                    break;
                }
                case '*': {
                    num = number[1] * number[2];
                    break;
                }
                case '/': {
                    num = number[1] / number[2];
                    break;
                }
            }
        } else if (j == 2) {
            //while(j>=0) {
            if (chars[0] == chars[1]) {
                for (t = 0; t < j; t++) {
                    switch (chars[t]) {
                        case '*':
                            num = number[t + 1] * number[t + 2];
                            break;
                        case '/':
                            num = number[t + 1] / number[t + 2];
                            break;
                        case '+':
                            num = number[t + 1] + number[t + 2];
                            break;
                        case '-':
                            num = number[t + 1] - number[t + 2];
                            break;
                    }
                    number[t + 1] = -9999;
                    number[t + 2] = num;
                    chars[t] = '!';
                    //zhengli();
                }
            } else {
                for (t = 0; t < j; t++) {
                    if (chars[t] == '*' || chars[t] == '/') {
                        switch (chars[t]) {
                            case '*':
                                num = number[t + 1] * number[t + 2];
                                break;
                            case '/':
                                num = number[t + 1] / number[t + 2];
                                break;
                        }
                        number[t + 1] = num;
                        number[t + 2] = -9999;
                        chars[t] = '!';
                    }
                    int p = 1;
                    for (int q = 1; q < i; q++)
                        if (number[q] != -9999) {
                            number[p] = number[q];
                            p++;
                        }
                }
                for (t = 0; t < j; t++) {

                    switch (chars[t]) {
                        case '+':
                            num = number[1] + number[2];
                            break;
                        case '-':
                            num = number[1] - number[2];
                            break;
                       /* case '*':
                            num=number[1]*number[2];
                            break;
                        case '/':
                            num=number[1]/number[2];
                            break;*/
            /*        }
                    number[t + 1] = num;
                    number[t + 2] = -9999;
                    chars[t] = '!';
                }

            }
        }
        else {
            int a = j;
            while (a-1>=0) {
                //锛堬級鍑虹幇鏃剁殑瑙ｅ喅鏂瑰紡
                for (t = 0; t < j; t++) {
                    if (chars[t] == '(') {   //浼樺厛绾т负锛堬級锛?  /锛?  -锛?
                        //chars鏄粠0寮€濮嬬殑锛沶umber鏄寮€濮嬬殑
                        n = t;
                        for (m = t + 1; m < j; m++) {
                            if (chars[m] == '*' || chars[m] == '/') {
                                switch (chars[m]) {
                                    case '*':
                                        num = number[m] * number[m + 1];
                                        break;
                                    case '/':
                                        num = number[m] / number[m + 1];//鍒嗘瘝涓?鏃秂rror;
                                        break;
                                }
                                number[m] = num;
                                number[m + 1] = -9999;
                                chars[m] = '!';
                            }
                            zhengli();
                        }
                        for (m = t + 1; m < j; m++) {
                            if (chars[m] == '+' || chars[m] == '-') {
                                switch (chars[m]) {
                                    case '+':
                                        num2 = number[m] + number[m + 1];
                                        break;
                                    case '-':
                                        num2 = number[m] - number[m + 1];//鍒嗘瘝涓?鏃秂rror;
                                        break;
                                }
                                number[m] = num2;
                                number[m + 1] = -9999;
                                chars[m] = '!';
                            }
                            zhengli();
                        }
                    }
                    chars[t] = '!';
                    chars[t + 1] = '!';//鍙虫嫭鍙穚ass
                    zhengli();
                }
                for (t = 0; t < n; t++) {
                    if (chars[t] == '*' || chars[t] == '/') {
                        switch (chars[t]) {
                            case '*':
                                num2 = number[t + 1] * number[t + 2];
                                break;
                            case '/':
                                num2 = number[t + 1] / number[t + 2];//鍒嗘瘝涓?鏃秂rror;
                                break;
                        }
                        number[t + 1] = num2;
                        number[t + 2] = -9999;
                        chars[t] = '!';
                    }
                    zhengli();
                }
                for (t = 0; t < n; t++) {
                    if (chars[t] == '+' || chars[t] == '-') {
                        switch (chars[t]) {
                            case '+':
                                num2 = number[t + 1] + number[t + 2];
                                break;
                            case '-':
                                num2 = number[t + 1] - number[t + 2];//鍒嗘瘝涓?鏃秂rror;
                                break;
                        }
                        number[t + 1] = num2;
                        number[t + 2] = -9999;
                        chars[t] = '!';
                    }
                    zhengli();
                }
            }
            // num=num1+num2;
            String s = String.valueOf(num);
            input = input + s;
            edittext.setText(input);
            //return result;
        }
    }
    public void zhengli(){
        int p=1;
        int t;
        for(t=1;t<i;t++)
            if(number[t]!=-9999){
                number[p]=number[t];
                p++;
            }
        for(;p<i;p++)
            number[p]=-9999;
        p=1;
        for(t=0;t<j;t++)
            if(chars[t]!='!'){
                chars[p]=chars[t];
                p++;
            }
        for(;p<j;p++)
            chars[p]='!';
    }


}
/*
input涓瓨鍌ㄨ緭鍏ュ唴瀹?
閫氳繃鍓嶅悗闀垮害纭畾涓棿娈垫暟瀛楃殑闀垮害涓庡ぇ灏?
chars=null;琛ㄧず灏嗘暟缁勫璞＄疆绌猴紱
chars[]=new char[100];
String str="4444.1122";

double num;

java.text.DecimalFormat myformat=new java.text.DecimalFormat("#0.00");

num=Double.parseDouble(str);//瑁呮崲涓篸ouble绫诲瀷

num=Double.parseDouble(myformat.format(num));//淇濈暀2涓哄皬鏁?

System.out.println(num);

 */
