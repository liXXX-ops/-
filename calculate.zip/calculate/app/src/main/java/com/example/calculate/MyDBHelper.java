package com.example.calculate;

import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.Context;
import android.widget.Toast;
//import java.sql.*;
//import android.os.Build.*;
public class MyDBHelper extends SQLiteOpenHelper {
    //public static final String TABLE_NAME="words";
    //public static String ID;
    //public static final String COLUMN_NAME_WORD="word";
    //public static final String COLUMN_NAME_MEANING="meaning";
    //public static final String COLUMN_NAME_SAMPLE="sample";
    private final static String DATABASE_NAME = "calculatedb";
    private final static int DATABASE_VERSION = 1;
    private final static String TABLE_NAME="calculate";
    private int id;
    private final static String shizi="shizi";
    private Context content;
    private final static String SQL_CREATE_DATABASE="create table "+
            TABLE_NAME+" ( "+     //tablename为words;
            shizi +" text PRIMARY KEY " +
            ")";


    private Context mcontext;

    private final static String SQL_DELETE_DATABASE="DROP TABLE IF EXISTS "+TABLE_NAME;

    public MyDBHelper(Context context,String name,SQLiteDatabase.CursorFactory factory,int version){
        super(context,name,factory,version);
        mcontext=context;
    }
    public void onCreate(SQLiteDatabase db){
        //db = openOrCreateDatabase(DATABASE_NAME, Context.MODE_PRIVATE,null);
        db.execSQL(SQL_CREATE_DATABASE);
        Toast.makeText(mcontext, "begin create", Toast.LENGTH_SHORT).show();
    }
    public void onUpgrade(SQLiteDatabase sqLiteDatabase,int oldVersion,int newVersion){
        sqLiteDatabase.execSQL(SQL_DELETE_DATABASE);
        onCreate(sqLiteDatabase);
    }
}
