package com.example.music;

public class Music{
    private static String name;
    private static String dbname;
    private static String musictable;

}
