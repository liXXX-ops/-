package com.example.contentprovider;

import android.database.Cursor;
import android.content.ContentProvider;
import android.content.*;
import android.database.SQLException;
import android.net.Uri;
import android.database.sqlite.*;
import android.os.Bundle;
import android.util.Log;
public class WordsProvider extends ContentProvider {



    private static final int MULTIPLE_WORDS = 1;
    private static final int SINGLE_WORD = 2;
    WordsDBHelper mDbHelper;

   public boolean onCreate() {
      mDbHelper=new WordsDBHelper(getContext(), "wordsdb.db", null, 2);
      Log.d("MMM","0000");
      return true;
}

    private static final UriMatcher uriMatcher=new UriMatcher(UriMatcher.NO_MATCH);


    static {
        uriMatcher.addURI(Words.AUTHORITY, Words.Word.PATH_SINGLE, SINGLE_WORD);
        uriMatcher.addURI(Words.AUTHORITY, Words.Word.PATH_MULTIPLE, MULTIPLE_WORDS);
    }

    public String getType(Uri uri) {
        switch (uriMatcher.match(uri)) {
            case MULTIPLE_WORDS:
                return Words.Word.MIME_TYPE_MULTIPLE;
            case SINGLE_WORD:
                return Words.Word.MIME_TYPE_SINGLE;
            default:
                throw new IllegalArgumentException("Unkonwn Uri" + uri);
        }
    }

    public int delete(Uri uri, String selection, String[] selectionArgs) {
        SQLiteDatabase db = mDbHelper.getReadableDatabase();
        int count = 0;
        switch (uriMatcher.match(uri)) {
            case MULTIPLE_WORDS:
                count = db.delete(Words.Word.TABLE_NAME, selection, selectionArgs);
                break;
            case SINGLE_WORD:
                String whereClause = Words.Word._ID + "=" + uri.getPathSegments().get(1);
                count = db.delete(Words.Word.TABLE_NAME,whereClause,selectionArgs);
                break;
            default:
                throw new IllegalArgumentException("UNk" + uri);
        }
        getContext().getContentResolver().notifyChange(uri, null);
        return count;
    }
    public Uri insert(Uri uri,ContentValues values) {
        SQLiteDatabase db = mDbHelper.getReadableDatabase();
        long id = db.insert(Words.Word.TABLE_NAME, null, values);
        if (id > 0) {
            Uri newUri = ContentUris.withAppendedId(Words.Word.CONTENT_URI, id);
            getContext().getContentResolver().notifyChange(newUri, null);
            return newUri;
        }
    throw new SQLException("fail"+uri);
    }

    public int update(Uri uri,ContentValues values,String select,String[] selectArgs) {
        SQLiteDatabase db=mDbHelper.getReadableDatabase();
        int count=0;
        switch(uriMatcher.match(uri)){
            case MULTIPLE_WORDS:
                count=db.update(Words.Word.TABLE_NAME,values,select,selectArgs);
                break;
            case SINGLE_WORD:
                String segment=uri.getPathSegments().get(1);
                count=db.update(Words.Word.TABLE_NAME,values,Words.Word._ID+"/"+segment,selectArgs);
                break;
            default:
                throw new IllegalArgumentException("Unknow"+uri);
        }
        getContext().getContentResolver().notifyChange(uri,null);
        return count;
    }

    public Cursor query(Uri uri,String []projection,String selection,String[] selectArgs,String sortOrder) {
        SQLiteDatabase db=mDbHelper.getReadableDatabase();
        SQLiteQueryBuilder qb=new SQLiteQueryBuilder();
        qb.setTables(Words.Word.TABLE_NAME);
        switch(uriMatcher.match(uri)){
            case MULTIPLE_WORDS:
                return db.query(Words.Word.TABLE_NAME,projection,selection,selectArgs,null,null,sortOrder);
            case SINGLE_WORD:
                qb.appendWhere(Words.Word._ID+"="+uri.getPathSegments().get(1));
                return qb.query(db,projection,selection,selectArgs,null,null,sortOrder);
            default:
                throw new IllegalArgumentException("Un"+uri);
        }
    }

}
