package com.example.pintu;
import android.view.LayoutInflater;
import android.widget.ListView;
import android.widget.ListAdapter;
import android.widget.AdapterView;
import android.view.View;
import android.os.Bundle;
import android.view.ViewGroup;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;
import com.example.pintu.Picture;
import java.util.ArrayList;
import java.util.List;
import androidx.recyclerview.widget.*;
import android.app.Activity;
import android.widget.Toast;

public class P_fragment extends Fragment {
/*
    private List<Picture> p_list=new ArrayList<Picture>();
    private RecyclerView recyclerView;
    private ViewGroup parent;
    private int viewTypes;
    private PictureAdapter.ViewHolder viewHolder;

    private SendMessageCommunitor sendMessage;
    public View onCreateView(LayoutInflater inflater,ViewGroup viewGroup,Bundle savedInstanceState){
        View view=inflater.inflate(R.layout.item,viewGroup,false);
        initPicture();
        recyclerView = (RecyclerView) view.findViewById(R.id.recycler_view);
        return view;
    }
    public void p_xianshi(){
        LinearLayoutManager layoutManager = new LinearLayoutManager(this.getActivity());
        layoutManager.setOrientation(LinearLayoutManager.HORIZONTAL);
        recyclerView.setLayoutManager(layoutManager);
        PictureAdapter pictureAdapter = new PictureAdapter(p_list);
        recyclerView.setAdapter(pictureAdapter);
    }
    public int click(){    //返回PictureAdapter中的点击事件
        PictureAdapter pictureAdapter = new PictureAdapter(p_list);
        //pictureAdapter.onCreateViewHolder(parent,viewTypes).imageView;
        viewHolder=pictureAdapter.onCreateViewHolder(parent,viewTypes);
        int m_position=viewHolder.getAdapterPosition();
        Picture picture=p_list.get(m_position);
        return picture.getP_id();
    }
    public void initPicture() {
        Picture picture1 = new Picture("pig", R.drawable.pig);
        p_list.add(picture1);
        Picture picture2 = new Picture("xiaoer", R.drawable.xiaoer);
        p_list.add(picture2);
        Picture picture3 = new Picture("xingkong", R.drawable.xingkong);
        p_list.add(picture3);
        Picture picture4 = new Picture("android", R.drawable.android);
        p_list.add(picture4);
    }
    //

    public void onAttach(Activity activity){
        super.onAttach(activity);
        sendMessage=(SendMessageCommunitor)activity;
    }
    /*
    public void onActivityCreated(Bundle savedInstanceState){
        super.onActivityCreated(savedInstanceState);
        recyclerView=(RecyclerView)getActivity().findViewById(R.id.recycler_view);
        recyclerView.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                int position=recyclerView.getId();
                Picture picture=p_list.get(position);
                Toast.makeText(getActivity(),"recyclerView.getId()",Toast.LENGTH_SHORT).show();
                sendMessage.sendMessage("open");

            }
        });
    }
P_fragment p_fragment=new P_fragment(){
}
     */
}
