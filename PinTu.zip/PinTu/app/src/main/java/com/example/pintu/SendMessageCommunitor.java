package com.example.pintu;

public interface SendMessageCommunitor {
    void sendMessage(String msg);
}
