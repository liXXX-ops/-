package com.example.pintu;
import android.view.LayoutInflater;
import android.widget.ArrayAdapter;
import java.util.List;
import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.recyclerview.widget.*;
import org.w3c.dom.Text;
/*
public class PictureAdapter extends RecyclerView.Adapter<PictureAdapter.ViewHolder>  {

    private List<Picture> picture_List;
    private ImageView yuantu;
    private OnItemClickListener mOnItemClickListener=null;
    public PictureAdapter(){}
    public PictureAdapter(List<Picture>pictureList){
        picture_List=pictureList;
    }
    public ViewHolder onCreateViewHolder(ViewGroup parent,int viewTypes){
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.p_item,parent,false);
        //RecyclerView的点击事件的实现：
        ViewHolder holder=new ViewHolder(view,mOnItemClickListener);
        return holder;
    }
    public void setmOnItemClickListener(OnItemClickListener listener){
        this.mOnItemClickListener=listener;
    }
    public void onBindViewHolder(ViewHolder holder,int position){
        Picture picture=picture_List.get(position);
        holder.imageView.setImageResource(picture.getP_id());
        holder.textView.setText(picture.getP_name());
    }
    public int getItemCount(){
        return picture_List.size();
    }

    public interface OnItemClickListener{
        void onItemClick(View view,int position);
    }
    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{
        private OnItemClickListener mlistener;
        View pictureView;
        ImageView imageView;
        TextView textView;
        public ViewHolder(View view,OnItemClickListener mlistener){
            super(view);
            view.setOnClickListener(this);
            pictureView=view;
            this.mlistener=mlistener;
            imageView=(ImageView)view.findViewById(R.id.picture_view);
            textView=(TextView)view.findViewById(R.id.picture_name);
            yuantu=(ImageView)view.findViewById(R.id.yuantu);
        }
        public void onClick(View v) {
            if (mlistener != null)
                mlistener.onItemClick(v, getAdapterPosition());//(int)v.getTag());   //getAdapterPosition();

        }
    }
}
//holder.pictureView.setOnClickListener(this);//{
            /*
            public void onClick(View v){
                int position=holder.getAdapterPosition();
                Picture picture=picture_List.get(position);
                if(mOnItemClickListener!=null){
                    mOnItemClickListener.onItemClick(v,(int)v.getTag());
                }
                //yuantu.setImageResource(picture.getP_id());void android.widget.ImageView.setImageResource(int)' on a null object reference
                //        at com.example.pintu.PictureAdapter$1.onClick(PictureAdapter.java:46)
                //Toast.makeText(v.getContext(),"*****"+picture.getP_name(),Toast.LENGTH_SHORT).show();
            }

        });*/
            /*
        holder.imageView.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                int position=holder.getAdapterPosition();
                Picture picture=picture_List.get(position);
               // Toast.makeText(v.getContext(),"*****"+picture.getP_name(),Toast.LENGTH_SHORT).show();
            }
        });

             */
/*
 */
 /*
 ArrayAdapter的点击适配器的框架：*/
public class PictureAdapter extends ArrayAdapter<Picture> {


    private int resourceId;
    public PictureAdapter(Context context,int resourceId,List<Picture> objects){
        super(context,resourceId,objects);
        this.resourceId=resourceId;

    }
    public View getView(int position,View view,ViewGroup parent){
        Picture picture=getItem(position);
        View v;
        ViewHolder viewHolder;
        if(view==null){
            v=LayoutInflater.from(getContext()).inflate(resourceId,parent,false);
            viewHolder=new ViewHolder();
            viewHolder.imageView=(ImageView)v.findViewById(R.id.picture_view);
            viewHolder.textView=(TextView)v.findViewById(R.id.picture_name);
            v.setTag(viewHolder);
        }else{
            v=view;
            viewHolder=(ViewHolder)v.getTag();
        }
        //ImageView imageView=(ImageView)v.findViewById(R.id.picture_view);
        //TextView textView=(TextView)v.findViewById(R.id.picture_name);
        //imageView.setImageResource(picture.getP_id());
        //textView.setText(picture.getP_name());
        viewHolder.imageView.setImageResource(picture.getP_id());
        viewHolder.textView.setText(picture.getP_name());
        return v;
    }
    class ViewHolder{
        ImageView imageView;
        TextView textView;
    }
}
