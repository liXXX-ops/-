package com.example.pintu;

public class Picture {
    private String p_name;
    private int p_id;
    public Picture(String p_name,int p_id){
        this.p_name=p_name;
        this.p_id=p_id;
    }
    public String getP_name(){
        return p_name;
    }
    public int getP_id(){
        return p_id;
    }

}
