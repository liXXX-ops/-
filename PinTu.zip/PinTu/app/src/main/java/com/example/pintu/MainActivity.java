package com.example.pintu;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.GestureDetector;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import android.widget.AdapterView;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.graphics.*;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;
import com.example.pintu.Picture;
import android.widget.Button;
import java.util.List;
import androidx.recyclerview.widget.*;
import android.widget.*;
public class MainActivity extends AppCompatActivity implements SendMessageCommunitor{
    // private GameView gameview;
    // private TextView tv_level;
    // private TextView tv_time;
    private boolean running = false;      //当前动画是否正在进行
    private boolean gameStarting = false;    //判断是否开始
    private ImageView[][] game_arr;  //创建游戏小方块

    private ImageView spaceDraw;   //当前空方块的实例保存
    private ImageView yuantu;
    private GestureDetector mDetector;     //当前手势
    private GridLayout gridLayout;      //游戏主界面
    private Button button;
    private TextView textView;
    private TextView click_number;
    Timer timer;
    int timecount = 0;
    int timecount1=100;
    int dianjicishu;     //
    boolean time_jilu = false;
    //private int n=0;
    private List<Picture> p_list = new ArrayList<Picture>();   //
    private RecyclerView recyclerView;
    private int dengji=3;   //锁定游戏的等级
    private P_fragment p_fragment;
    private int p_id;
    private RadioGroup radioGroup;
    private String moshi="";
    private boolean GameOver;
    private ListView listView;
    private ListView listView1;
    private ListView listView2;
    private ListView listView3;
    PictureAdapter pictureAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        pintu_jiemian(3,R.drawable.android);
//RecyclerView显示滑动图片利用fragment代替掉：
        initPicture();
        /*
        recyclerView = (RecyclerView) findView
        ById(R.id.recycler_view);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        layoutManager.setOrientation(LinearLayoutManager.HORIZONTAL);
        recyclerView.setLayoutManager(layoutManager);
        PictureAdapter pictureAdapter = new PictureAdapter(p_list);
        recyclerView.setAdapter(pictureAdapter);
        */
        listView=(ListView)findViewById(R.id.listview);
        pictureAdapter = new PictureAdapter(MainActivity.this,R.layout.p_item,p_list);
        //ArrayAdapter adapter=new ArrayAdapter(MainActivity.this,R.layout.p_item,p_list);
        listView.setAdapter(pictureAdapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Picture picture = p_list.get(position);
                int p_id = picture.getP_id();
                //yuantu.setImageResource(p_id);
                setContentView(R.layout.activity_main);
                listView.setAdapter(pictureAdapter);
                pintu_jiemian(dengji,p_id);
            }
        });
        //通过碎片代替RecyclerView,显示替换图片；
        //p_fragment=(P_fragment)getSupportFragmentManager().findFragmentById(R.id.p_fragment);
        //p_fragment.p_xianshi();
        //p_id=p_fragment.click();
        //PictureAdapter pictureAdapter=new PictureAdapter(p_list);
//        recyclerView.setAdapter(pictureAdapter);
        //click_number=(TextView)findViewById(R.id.click_number);   on a null object reference
/*
        recyclerView=(RecyclerView)findViewById(R.id.recycler_view);

        recyclerView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                yuantu.setImageResource(R.drawable.pig);
            }
        });
        */
        radioGroup=(RadioGroup)findViewById(R.id.radio_group);
        radioGroup.setOnCheckedChangeListener(check);

       /* PictureAdapter pictureAdapter=new PictureAdapter();
        pictureAdapter.setmOnItemClickListener(new PictureAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(View view, int position) {
                Toast.makeText(MainActivity.this,position+"......",Toast.LENGTH_SHORT).show();
            }
        });*/
    }
    public RadioGroup.OnCheckedChangeListener check=new RadioGroup.OnCheckedChangeListener() {
        @Override
        public void onCheckedChanged(RadioGroup group, int checkedId) {
            switch (checkedId) {
                case R.id.yule: {
                    time_jilu=false;
                    moshi="yule";
                    break;
                }
                case R.id.jishi: {
                    time_jilu=false;
                    moshi="jishi";
                    break;
                }
            }
        }
    };
    public void sendMessage(String msg){
        Toast.makeText(MainActivity.this,"*/////",Toast.LENGTH_SHORT).show();
    }
    //响应item的点击事件
    public void onItemClick(PictureAdapter args,View v,int position,long id){
        Toast.makeText(this,"****"+position,Toast.LENGTH_SHORT).show();
    }
    //相映按钮点击事件
    public void onClick(View v,int position){
        Toast.makeText(this,"****"+(Integer)v.getTag(),Toast.LENGTH_SHORT).show();
    }


    //pintu__
    public void pintu_jiemian(int n,int r) {
        //setContentView(R.layout.activity_main);
        game_arr = new ImageView[n][n];
        mDetector = new GestureDetector(this, new GestureDetector.OnGestureListener() {
            @Override
            public boolean onDown(MotionEvent e) {
                return false;
            }

            @Override
            public void onShowPress(MotionEvent e) {
            }

            @Override
            public boolean onSingleTapUp(MotionEvent e) {
                return false;
            }

            @Override
            public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY) {
                return false;
            }

            @Override
            public void onLongPress(MotionEvent e) {
            }

            @Override
            //一瞬间执行的方法-------触摸屏
            public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {      //motionevent存储我们当前手指移动的状态：
                int type = getDirByGes(e1.getX(), e1.getY(), e2.getX(), e2.getY());
                changeByDir(type, true);
                return false;
            }
        });
        yuantu = (ImageView) findViewById(R.id.yuantu);
        button = (Button) findViewById(R.id.begin_button);
        textView = (TextView) findViewById(R.id.begin_time);
        click_number=(TextView)findViewById(R.id.click_number);
        //setContentView(R.layout.activity_main);
//初始化游戏的若干小方块
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                timecount=0;
                timecount1=100;
                if (time_jilu == false) {
                    time_jilu = true;
                    timer = new Timer();
                    TimerTask timerTask = new TimerTask() {
                        @Override
                        public void run() {
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    if(moshi.equals("yule")){
                                    timecount++;
                                    textView.setText(String.valueOf(timecount));
                                    }else{
                                        timecount1--;
                                        textView.setText(String.valueOf(timecount1));
                                    }
                                    if (timecount > 100) {
                                        timer.cancel();
                                        Toast.makeText(MainActivity.this, "游戏时间已到", Toast.LENGTH_SHORT).show();
                                        return;
                                    }
                                }
                            });
                        }
                    };
                    timer.schedule(timerTask, 1000, 1000);
                    /*
                    Timer.schedule(TimerTask task, long delay, long period)：延时delay毫秒后周期性的执行task，其中周期是period毫秒
                    Timer.schedule(TimerTask task, long delay)：延时delay毫秒后执行task。
                    区别：前者是周期性执行任务，后者是只执行一次。
                     */
                } else {
                    timer.cancel();
                    //时间到了：
                }
            }
        });
        yuantu.setImageResource(r);
        Bitmap bitmap = ((BitmapDrawable) getResources().getDrawable(r)).getBitmap();
        int everyWidth = bitmap.getWidth() / n;
        for (int i = 0; i < game_arr.length; i++)
            for (int j = 0; j < game_arr[0].length; j++) {                    //iv_game_arr为image型
                Bitmap bm = Bitmap.createBitmap(bitmap, j * everyWidth, i * everyWidth, everyWidth, everyWidth);   //指定起始坐标以及截取图片的大小
                game_arr[i][j] = new ImageView(this);
                //处理空指针异常的解决办法
                game_arr[i][j].setImageBitmap(bm);    //设置每一个游戏小方块的图案         //初次错误为在空对象引用上
                game_arr[i][j].setPadding(2, 2, 2, 2);   //设置方块之间的间距
                game_arr[i][j].setTag(new GameData(i, j, bm));   //绑定自定义的数据
                game_arr[i][j].setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        boolean flag = isHasByNullImageView((ImageView) view);    //判断方块与空方块的位置，相邻时返回true;
                        if (flag)
                            changeDataByImageView((ImageView) view);              //
                    }
                });
            }
//初始化游戏界面；
        gridLayout = (GridLayout) findViewById(R.id.gridlayout);
        for (int i = 0; i < game_arr.length; i++)
            for (int j = 0; j < game_arr[0].length; j++)
                gridLayout.addView(game_arr[i][j]);
        setSpaceDraw(game_arr[n - 1][n - 1]);
        randomMove();       //交换性打乱保证其有解；
        gameStarting = true;
    }

    //得到手势的方向：
    public int getDirByGes(float start_x, float start_y, float end_x, float end_y) {
        boolean isLeftOrRight = (Math.abs(start_x - end_x) > Math.abs(start_y - end_y)) ? true : false;
        if (isLeftOrRight) {
            boolean isLeft = start_x - end_x > 0 ? true : false;
            if (isLeft) return 3;          //向左移动：
            else return 4;
        } else {//上下判别代码
            boolean isUp = start_y - end_y > 0 ? true : false;
            if (isUp) return 1;  //上
            else return 2;
        }
    }
    //根据手势的方向，获取空方块相邻位置如果存在方块，那么进行数据交换
    public void changeByDir(int type, boolean isAnim) {
        //type:1: 向上移动实际方块     2: 下    3: 左     4: 右
        GameData mNullGameDate = (GameData) spaceDraw.getTag();    //获取VIew添加的额外数据
        int new_x = mNullGameDate.x;
        int new_y = mNullGameDate.y;
        if (type == 1)
            new_y++;         //空方块在上方，移动后空方块的x值加一，实际方块的x值减一
        else if (type == 2)     //上方
            new_y--;
        else if (type == 3)    //左
            new_x++;
        else if (type == 4)     //右
            new_x--;
        if (new_x >= 0 && new_x < game_arr.length && new_y >= 0 && new_y < game_arr[0].length) {
            if (isAnim)   //存在时开始移动
                changeDataByImageView(game_arr[new_x][new_y]);
            else
                changeDataByImageView(game_arr[new_x][new_y], isAnim);
        } else {
        }
    }

    public void changeDataByImageView(final ImageView mImageView) {
        changeDataByImageView(mImageView, true);
    }

    //利用动画结束之后，交换两个方块的数据
    public void changeDataByImageView(final ImageView imageView, final boolean isAnim) {
        if (running) {   //如果动画已经开始，则不做交换操作
            return;
        }
        if (!isAnim) {
            int t1 = 0;
            int t2 = 0;
            GameData gameData = (GameData) imageView.getTag();     //确当此时对应的那张图片；
            spaceDraw.setImageBitmap(gameData.bm);        ////交换图片交换坐标    同时将Bitmap装换成ImageView;

            GameData spaceGameData = (GameData) spaceDraw.getTag();
            spaceGameData.bm = gameData.bm;
            ////spaceGameData.x=gameData.x;   部分将点击出现问题
            //t1=spaceGameData.p_x;
            spaceGameData.p_x = gameData.p_x;
            // gameData.p_x=t1;
            // t2=spaceGameData.p_y;
            spaceGameData.p_y = gameData.p_y;
            // gameData.p_y=t2;

            setSpaceDraw(imageView);     //设置当前点击的是空方块，x与y相关的参数没有问题；
            /*if (gameStarting) {
                GameIsOver();
                ;
            }

             */
            return;
        }
        /*
        PictureAdapter pictureAdapter=new PictureAdapter(p_list);
        pictureAdapter.setmOnItemClickListener(new PictureAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(View view, int position) {
                Toast.makeText(MainActivity.this,position+"......",Toast.LENGTH_SHORT).show();
            }
        });*/

        //创建一个动画，设置好方向，移动的距离
        TranslateAnimation translateAnimation = null;   //位移动画效果
        if (imageView.getY() > spaceDraw.getY() && imageView.getX() == spaceDraw.getX())
            //往上移动
            translateAnimation = new TranslateAnimation(0.1f, 0.1f, 0.1f, -imageView.getWidth());   //from与to是从下移动到上面
        else if (imageView.getY() < spaceDraw.getY() && imageView.getX() == spaceDraw.getX())
            //往下移动
            translateAnimation = new TranslateAnimation(0.1f, 0.1f, 0.1f, imageView.getWidth());
        else if (imageView.getX() > spaceDraw.getX() && imageView.getY() == spaceDraw.getY())
            //往左移动
            translateAnimation = new TranslateAnimation(0.1f, -imageView.getWidth(), 0.1f, 0.1f);
        else if (imageView.getX() < spaceDraw.getX() && imageView.getY() == spaceDraw.getY())
            //往右移动
            translateAnimation = new TranslateAnimation(0.1f, imageView.getWidth(), 0.1f, 0.1f);
        translateAnimation.setDuration(1000);       //设置动画的时长
        translateAnimation.setFillAfter(true);    //动画停止时停留在最后一帧，否则返回到千亿帧
        translateAnimation.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {
                running = true;
            }

            @Override
            public void onAnimationEnd(Animation animation) {
                dianjicishu++;
                click_number.setText(String.valueOf(dianjicishu));
                int t1 = 0, t2 = 0;
                running = false;
                imageView.clearAnimation();
                GameData gameData = (GameData) imageView.getTag();
                spaceDraw.setImageBitmap(gameData.bm);
                GameData spaceGameData = (GameData) spaceDraw.getTag();
                spaceGameData.bm = gameData.bm;
                t1 = spaceGameData.p_x;
                spaceGameData.p_x = gameData.p_x;
                gameData.p_x = t1;
                t2 = spaceGameData.p_y;
                spaceGameData.p_y = gameData.p_y;
                gameData.p_y = t2;
                setSpaceDraw(imageView);
                if (gameStarting)
                    GameIsOver();
            }

            @Override
            public void onAnimationRepeat(Animation animation) {
            }
        });
        imageView.startAnimation(translateAnimation);
    }

    public void setSpaceDraw(ImageView mImageView) {
        mImageView.setImageBitmap(null);
        spaceDraw = mImageView;
    }

    //判断当前方块与空方块是否相邻，true为相邻，false为不相邻；
    public boolean isHasByNullImageView(ImageView mImageView) {
        GameData spaceGameData = (GameData) spaceDraw.getTag();
        GameData mGameData = (GameData) mImageView.getTag();
        if (spaceGameData.y == mGameData.y && mGameData.x + 1 == spaceGameData.x) {  //在空方块的上方    //横向为y，纵向为x
            return true;
        } else if (spaceGameData.y == mGameData.y && mGameData.x - 1 == spaceGameData.x) {  //下方
            return true;
        } else if (spaceGameData.y == (mGameData.y - 1) && mGameData.x == spaceGameData.x) {   //在空方块的右方
            return true;
        } else if (spaceGameData.y == (mGameData.y + 1) && mGameData.x == spaceGameData.x) {     //在空方块的左方
            return true;
        }
        return false;
    }

    public void GameIsOver() {
        GameOver = true;
        for (int i = 0; i < game_arr.length; i++)
            for (int j = 0; j < game_arr[0].length; j++) {
                if (game_arr[i][j] == spaceDraw)
                    continue;
                GameData gameData = (GameData) game_arr[i][j].getTag();
                if (!gameData.isTrue()) {
                    GameOver = false;
                    break;
                }
            }
        if (GameOver) {
            //设置弹窗:
            //timer.cancel();
            dianjicishu=0;
            AlertDialog.Builder dialog = new AlertDialog.Builder(MainActivity.this);
            dialog.setTitle("游戏结束");
            if(moshi!=""){
                if(moshi.equals("yule")) {
                    dialog.setMessage("恭喜游戏结束，拼图完成，用时" + textView.getText()+",点击次数为:"+click_number.getText());
                }else {
                    int a=100-Integer.parseInt(textView.getText().toString());
                    dialog.setMessage("恭喜游戏结束，拼图完成，用时"+String.valueOf(a)+",点击次数为:"+click_number.getText());
                }
            }else
                dialog.setMessage("恭喜游戏结束，拼图完成"+",点击次数为:"+click_number.getText());
            dialog.setCancelable(false);
            dialog.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {

                }
            });
            dialog.setNegativeButton("cancel", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {

                }
            });
            dialog.show();
            //Toast.makeText(this, "游戏结束", Toast.LENGTH_LONG).show();
        }
    }

    public void randomMove() {
        for (int i = 0; i < 10; i++) {
            //根据手势开始交换
            int type = (int) (Math.random() * 4) + 1;
            changeByDir(type, false);
        }
    }

    public boolean onTouchEvent(MotionEvent event) {   //手势监听
        return mDetector.onTouchEvent(event);
    }
    public boolean dispatchTouchEvent(MotionEvent event) {  //在图片上进行手势滑动；
        mDetector.onTouchEvent(event);
        return super.dispatchTouchEvent(event);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        //return super.onCreateOptionsMenu(menu);
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        switch (id) {
            case R.id.jiandan: {
                GameOver=false;
                dianjicishu=0;
                //click_number.setText(dianjicishu);
                dengji=3;
                setContentView(R.layout.activity_main_1);
                //P_fragment p_fragment1=(P_fragment)getSupportFragmentManager().findFragmentById(R.id.p_fragment1);
                //p_fragment1.p_xianshi();
                pintu_jiemian(3,R.drawable.android);
                listView1=(ListView)findViewById(R.id.listview1);
                PictureAdapter pictureAdapter = new PictureAdapter(MainActivity.this,R.layout.p_item,p_list);
                listView1.setAdapter(pictureAdapter);
                listView1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                        Picture picture = p_list.get(position);
                        int p_id = picture.getP_id();
                        pintu_jiemian(dengji,p_id);
                    }
                });
                break;
            }
            case R.id.yiban: {
                GameOver=false;    //否则切换界面后会出现弹窗
                dianjicishu=0;
                //click_number.setText(dianjicishu);
                dengji=4;
                setContentView(R.layout.activity_main_2);
                pintu_jiemian(4,R.drawable.android);
                //P_fragment p_fragment2=(P_fragment)getSupportFragmentManager().findFragmentById(R.id.p_fragment2);
                //p_fragment2.p_xianshi();
                listView2=(ListView)findViewById(R.id.listview2);
                PictureAdapter pictureAdapter = new PictureAdapter(MainActivity.this,R.layout.p_item,p_list);
                listView2.setAdapter(pictureAdapter);
                listView2.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                        Picture picture = p_list.get(position);
                        int p_id = picture.getP_id();
                        pintu_jiemian(dengji,p_id);
                    }
                });
                break;
            }
            case R.id.kunnan: {
                GameOver=false;
                dianjicishu=0;
                //click_number.setText(dianjicishu);
                dengji=5;
                setContentView(R.layout.activity_main_3);
                pintu_jiemian(5,R.drawable.android);
                //P_fragment p_fragment3=(P_fragment)getSupportFragmentManager().findFragmentById(R.id.p_fragment3);
                //p_fragment3.p_xianshi();
                listView3=(ListView)findViewById(R.id.listview3);
                PictureAdapter pictureAdapter = new PictureAdapter(MainActivity.this,R.layout.p_item,p_list);
                listView3.setAdapter(pictureAdapter);
                listView3.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                        Picture picture = p_list.get(position);
                        int p_id = picture.getP_id();
                        pintu_jiemian(dengji,p_id);
                    }
                });
                break;
            }
        }
        return true;//onOptionsItemSelected(item);
    }
    public void initPicture() {
        Picture picture1 = new Picture("pig", R.drawable.pig);
        p_list.add(picture1);
        Picture picture2 = new Picture("xiaoer", R.drawable.xiaoer);
        p_list.add(picture2);
        Picture picture3 = new Picture("xingkong", R.drawable.xingkong);
        p_list.add(picture3);
        Picture picture4 = new Picture("android", R.drawable.android);
        p_list.add(picture4);
    }
    ////图片变换后调用来显示结果：
    public void pintu_jiemian_bianhua(int n,int p_id) {
        //setContentView(R.layout.activity_main);
        game_arr = new ImageView[n][n];
        mDetector = new GestureDetector(this, new GestureDetector.OnGestureListener() {
            @Override
            public boolean onDown(MotionEvent e) {
                return false;
            }
            @Override
            public void onShowPress(MotionEvent e) {
            }
            @Override
            public boolean onSingleTapUp(MotionEvent e) {
                return false;
            }
            @Override
            public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY) {
                return false;
            }
            @Override
            public void onLongPress(MotionEvent e) {
            }
            @Override
            //一瞬间执行的方法-------触摸屏
            public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {      //motionevent存储我们当前手指移动的状态：
                int type = getDirByGes(e1.getX(), e1.getY(), e2.getX(), e2.getY());
                changeByDir(type, true);
                return false;
            }
        });
        yuantu = (ImageView) findViewById(R.id.yuantu);
        button = (Button) findViewById(R.id.begin_button);
        textView = (TextView) findViewById(R.id.begin_time);
        //setContentView(R.layout.activity_main);
//初始化游戏的若干小方块
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (time_jilu == false) {
                    time_jilu = true;
                    timer = new Timer();
                    TimerTask timerTask = new TimerTask() {
                        @Override
                        public void run() {
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    timecount++;
                                    textView.setText(String.valueOf(timecount));
                                    if (timecount > 100) {
                                        timer.cancel();
                                        Toast.makeText(MainActivity.this, "游戏时间已到", Toast.LENGTH_SHORT).show();
                                        return;
                                    }
                                }
                            });
                        }
                    };
                    timer.schedule(timerTask, 1000, 1000);
                    /*
                    Timer.schedule(TimerTask task, long delay, long period)：延时delay毫秒后周期性的执行task，其中周期是period毫秒
                    Timer.schedule(TimerTask task, long delay)：延时delay毫秒后执行task。
                    区别：前者是周期性执行任务，后者是只执行一次。
                     */
                } else {
                    timer.cancel();
                    //时间到了：
                }
            }
        });
        yuantu.setImageResource(p_id);
        Bitmap bitmap = ((BitmapDrawable) getResources().getDrawable(p_id)).getBitmap();
        int everyWidth = bitmap.getWidth() / n;
        for (int i = 0; i < game_arr.length; i++)
            for (int j = 0; j < game_arr[0].length; j++) {                    //iv_game_arr为image型
                Bitmap bm = Bitmap.createBitmap(bitmap, j * everyWidth, i * everyWidth, everyWidth, everyWidth);   //指定起始坐标以及截取图片的大小
                game_arr[i][j] = new ImageView(this);
                //处理空指针异常的解决办法
                game_arr[i][j].setImageBitmap(bm);    //设置每一个游戏小方块的图案         //初次错误为在空对象引用上
                game_arr[i][j].setPadding(2, 2, 2, 2);   //设置方块之间的间距
                game_arr[i][j].setTag(new GameData(i, j, bm));   //绑定自定义的数据
                game_arr[i][j].setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        boolean flag = isHasByNullImageView((ImageView) view);    //判断方块与空方块的位置，相邻时返回true;
                        if (flag)
                            changeDataByImageView((ImageView) view);              //
                    }
                });
            }
//初始化游戏界面；
        gridLayout = (GridLayout) findViewById(R.id.gridlayout);
        for (int i = 0; i < game_arr.length; i++)
            for (int j = 0; j < game_arr[0].length; j++)
                gridLayout.addView(game_arr[i][j]);
        setSpaceDraw(game_arr[n - 1][n - 1]);
        randomMove();       //交换性打乱保证其有解；
        gameStarting = true;
    }

    class GameData {
        public int x = 0;  //每个小方块的实际位置,当前位置
        public int y = 0;  //
        public Bitmap bm;  //每个小图片
        public int p_x = 0;   //每个小方块的位置，
        public int p_y = 0;

        public GameData(int x, int y, Bitmap bm) {
            this.x = x;
            this.y = y;
            this.bm = bm;
            this.p_x = x;
            this.p_y = y;
        }

        public boolean isTrue() {
            if (x == p_x && y == p_y)
                return true;
            return false;
        }
    }
}
/*
0 1 2 3 4 XXXX
0
1
2
Y
 <fragment
            android:id="@+id/fragment"
            android:name="com.example.pintu.P_fragment"
            android:layout_width="220dp"
            android:layout_height="88dp" />
模式：娱乐模式----比赛模式：记时间与倒记时间；
 */

/*
activity_main.xml中的替换
之前的RecyclerView
<androidx.recyclerview.widget.RecyclerView
        android:id="@+id/recycler_view"
        android:layout_width="match_parent"
        android:layout_height="132dp"
        android:layout_row="1"
        android:layout_column="0"
        android:layout_gravity="center_horizontal"
        android:fadingEdge="horizontal"/>
 */
/*
activity与fragment之间的数据传输有了一定的了解与学习
 */